import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.js";
import Navbar from "./components/Navbar";
import Home from "./components/Home";
import Category from "./components/Category";
import Product from "./components/Product";
import Blog from "./components/Blog";
import Phone from "./components/Phone";
import Footer from "./components/Footer";
function App() {
  return (
    <>
      <div className="container-fluid">
        <Navbar />
        <Home />
        <Category />
        <Product />
        <Blog />
        <Phone />
        <Footer />
      </div>
    </>
  );
}

export default App;
